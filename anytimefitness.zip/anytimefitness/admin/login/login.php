<?php

    // include '../../config/config.php';
    
    // class add extends Connection{

    //     public function managadd(){
        
    //         $fullname = 'admin';
    //         $username = 'admin';
    //         $password = password_hash('admin', PASSWORD_DEFAULT);
    //         $passwordtxt = 'admin';


    //         $sqlinsert = " INSERT INTO tbl_users_admin (username,password) VALUES (?,?) ";
    //         $statementinsert = $this->conn()->prepare($sqlinsert);
    //         $statementinsert->execute([$username,$password]);

    //     }

    // }

    // $adddata = new add();
    // $adddata->managadd();

?>




<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../asset/bootstrap.min.css">
        <link rel="stylesheet" href="../asset/login.css">

        <title>Pump House</title>
    </head>

    <body>

        <div class="wrapper" style="max-width: 100%;width: 400px;position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);">

            <h2 class="text-center ">Login</h2>
            <br>

            <form method="POST" action="../../controller/loginController.php">

              <div class="form-group">

                <label for="exampleInputEmail1">Username</label>
                <input type="text" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username">

              </div>

              <div class="form-group">

                <label for="exampleInputPassword1">Password</label>
                <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">

              </div>

              <div class="float-right"><button type="submit" name="submit" class="btn btn-danger rounded-0 pl-5 pr-5">Login</button></div>

            </form> 

        </div>
     
        <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
        <script src="../asset/jquery.slim.min.js"></script>
        <script src="../asset/bootstrap.bundle.min.js"></script>

    </body>

</html>