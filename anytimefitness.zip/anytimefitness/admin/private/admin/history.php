
<?php include '../../login/session.php'; ?>
<?php
include '../../../config/config.php';

    // Class Function
    class senior extends Connection{ 

            // senior Function
        public function managesenior(){ 
?>
<!doctype html>

<html lang="en">
    
    <head>

        <!-- CSS -->
        <?php require_once 'header.php'; ?>
            
    </head>
    
    <body style="background-color: #ecf2fd;overflow-x: hidden;">

        <div style="display: flex;">

            <!-- Sidebar -->
            <?php include '../include/sidebar.php'; ?>


            <!-- Top Navbar -->
            <?php include '../include/topnavbar.php'; ?>

        </div>

        <div class="whole_container_content">

            <div class="header_title">

                <h4>History</h4>

            </div>

            <div class="row p-4">
                
                <div class="col-lg-12 m-auto">
                
                    <div class="card border-0 card_table">


                
                        <div class="card-body">

                            <div id="createsenior" style="text-align: right;">
                            
                            </div>

                            <br>

                            <div id="style-1" class="table-responsive">

                                <table class="table table-striped table-bordered table-sm dataTables-example" width="100%">
                                 
                                  <thead>
                                  
                                    <tr>

                                        <th class="th-sm">Id</th>
                                        <th class="th-sm">Name</th>
                                        <th class="th-sm">Plan Name</th>
                                        <th class="th-sm">Amount</th>
                                        <th class="th-sm">Duration</th>
                                        <th class="th-sm">From</th>
                                        <th class="th-sm">To</th>
                                    
                                    </tr>
                                  </thead>

                                  <tbody id="table">

                                  </tbody>

                                </table>

                            </div>

                        </div>
                
                    </div>
                
                </div>

            </div>

        </div>

        <!-- JS -->
        <?php include 'footer.php'; ?>

        <?php include 'modal/modalreserved.php'; ?>

        <script>

            function loadingdata(){

                $.ajax({

                    url: "history_data.php",
                    type: "POST",
                    cache:false,

                    success: function(dataResult){

                        $('#table').html(dataResult)

                    }

                })

            }

            loadingdata()

            

           





        </script>

    </body>

</html>

<?php 

        }
        
    }

    $senior = new senior();
    $senior->managesenior();
   
?>