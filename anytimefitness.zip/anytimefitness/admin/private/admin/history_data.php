<?php

    include '../../../config/config.php';

    // Class Function
    class senior extends Connection{ 

	        // senior Function
        public function managesenior(){ 

            $sql = "SELECT *,tbl_reserved.id AS reserved_id FROM tbl_reserved INNER JOIN tbl_plan ON tbl_reserved.plan_id=tbl_plan.id WHERE status = 1";
            $stmt = $this->conn()->query($sql);
            $id = 1;

            while ($row = $stmt->fetch()) { ?>

                <tr class="gradeU">

                    <td><?php echo $id; ?></td>
                    <td><?php echo $row['name']; ?></td> 
                    <td><?php echo $row['plan_name']; ?></td> 
                    <td><?php echo $row['amount']; ?></td> 
                    <td><?php echo $row['duration']; ?></td> 
                    <td><?php echo $row['from_date']; ?></td> 
                    <td><?php echo $row['to_date']; ?></td> 

                </tr>

<?php 
                $id++;  

            }

	    }
        
	}

    $senior = new senior();
    $senior->managesenior();
   
?>


<script>

       $(document).ready(function() {

        $('.dataTables-example').DataTable({ destroy: true,  retrieve: true, });
      
        });
       
</script>