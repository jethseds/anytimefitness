<?php

    include '../../../config/config.php';

    // Class Function
    class senior extends Connection{ 

	        // senior Function
        public function managesenior(){ 

            $sql = "SELECT *,tbl_reserved.id AS reserved_id FROM tbl_reserved INNER JOIN tbl_plan ON tbl_reserved.plan_id=tbl_plan.id WHERE status = 0";
            $stmt = $this->conn()->query($sql);
            $id = 1;

            while ($row = $stmt->fetch()) { ?>

                <tr class="gradeU">

                    <td><?php echo $id; ?></td>
                    <td style="display: none;"><?php echo $row['reserved_id']; ?></td> 
                    <td style="display: none;"><?php echo $row['plan_id']; ?></td> 
                    <td><?php echo $row['name']; ?></td> 
                    <td><?php echo $row['plan_name']; ?></td> 
                    <td><?php echo $row['amount']; ?></td> 
                    <td><?php echo $row['duration']; ?></td> 
                    <td><?php echo $row['from_date']; ?></td> 
                    <td><?php echo $row['to_date']; ?></td> 
                    <td style="display: flex;">

                        <button id="edit_van" class="btn btn-primary d-flex align-items-center" data-toggle="modal" data-target="#modalvanedit"><i class="fas fa-edit"></i> </button> &nbsp;
                        <button id="delete_van" class="btn btn-danger d-flex align-items-center" data-toggle="modal" data-target="#modalvandelete"><i class="fas fa-trash"></i> </button>

                    </td> 

                </tr>

<?php 
                $id++;  

            }

	    }
        
	}

    $senior = new senior();
    $senior->managesenior();
   
?>


<script>

       $(document).ready(function() {

        $('.dataTables-example').DataTable({ destroy: true,  retrieve: true, });
      
        });
       
</script>