
<!-- Bootstrap JS -->
<script src="../bootstrap/jquery.slim.min.js"></script>
<script src="../bootstrap/bootstrap.bundle.min.js"></script>

<!-- jQuery JS -->
<script src="../js/jquery-3.6.0.min.js"></script>

<!-- Loader JS -->
<script src="../js/loader.js"></script>

<!-- Fontawesome JS -->
<script src="../js/fontawesome.js"></script>

<!-- App JS -->
<script src="../js/app.js"></script>

<!-- Chart JS -->
<script src="../js/jsdelivrchart.js"></script>
<script src="../js/chart.js"></script>

<!-- Datatable JS -->
<script src="../js/jquery.dataTables.min.js"></script>

<!-- Bootstrap Datatable JS -->
<script src="../js/dataTables.bootstrap4.min.js"></script>

<script src="../../../asset/app.js"></script>


<script src="../js/bootstrap.min.js"></script>
