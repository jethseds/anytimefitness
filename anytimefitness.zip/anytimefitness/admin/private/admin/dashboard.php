
<?php include '../../login/session.php'; ?>
<?php include '../../../config/config.php'; ?>

<?php

     class data extends Connection{ 

        public function managedata(){   

       
            $totalreserved = $this->conn()->query(" SELECT COUNT(id) AS totalreserved FROM tbl_reserved WHERE status = 0 ")->fetch();
            $totalcompleted = $this->conn()->query(" SELECT COUNT(id) AS totalcompleted FROM tbl_reserved WHERE status = 1 ")->fetch();
            $totalplan = $this->conn()->query(" SELECT COUNT(id) AS totalplan FROM tbl_plan")->fetch();
            $totalrevenue = $this->conn()->query(" SELECT SUM(tbl_plan.amount) AS totalrevenue FROM tbl_reserved INNER JOIN tbl_plan ON tbl_reserved.plan_id=tbl_plan.id WHERE status = 1 ")->fetch();

?>


<!doctype html>

<html lang="en">
    
    <head>

        <!-- CSS -->
        <?php require_once 'header.php'; ?>
            
    </head>
    
    <body style="background-color: #ecf2fd;overflow-x: hidden;">

        <div style="display: flex;">

            <!-- Sidebar -->
            <?php include '../include/sidebar.php'; ?>

            <!-- Top Navbar -->
            <?php include '../include/topnavbar.php'; ?>

        </div>

        <div class="whole_container_content">

            <div class="row p-4">
                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_name" style="background-color: #f55858;">

                            <h5 class="text-white font-weight-bold">Welcome Admin! <span class="float-right"><i class="fas fa-user-circle"></i></span></h5>
                            <label class="text-white"><?php echo date('F d, Y'); ?></label>

                            <button class="mt-4 view_more" style="color: #f55858;">view more</button>

                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees" style="background-color: #f5b358;">

                            <h6 class="font-weight-bold text-white">Total Reserved</h6>

                            <button class="view_more view_more_color bg-white" style="color: #f5b358;"><i class="fas fa-users"></i></button>

                            <div class="mt-1 h5 text-white">Total : <?php echo $totalreserved['totalreserved']; ?> &nbsp;&nbsp;</div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees" style="background-color: #9bebc4;">

                            <h6 class="font-weight-bold text-white">Total Completed</h6>

                            <button class="view_more view_more_color bg-white" style="color: #9bebc4;"><i class="fas fa-users"></i></button>

                            <div class="mt-1 h5 text-white">Total : <?php echo $totalcompleted['totalcompleted']; ?> &nbsp;&nbsp;</div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees" style="background-color: #9bebc4;">

                            <h6 class="font-weight-bold text-white">Total Plan</h6>

                            <button class="view_more view_more_color bg-white" style="color: #9bebc4;"><i class="fas fa-users"></i></button>

                            <div class="mt-1 h5 text-white">Total : <?php echo $totalplan['totalplan']; ?> &nbsp;&nbsp;</div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees" style="background-color: #9bebc4;">

                            <h6 class="font-weight-bold text-white">Total Revenue</h6>

                            <button class="view_more view_more_color bg-white" style="color: #9bebc4;"><i class="fas fa-users"></i></button>

                            <div class="mt-1 h5 text-white">Total : <?php echo $totalrevenue['totalrevenue']; ?> &nbsp;&nbsp;</div> 


                        </div>

                    </div>

                </div>


            </div>

        </div>


        <!-- JS -->
        <?php include 'footer.php'; ?>
    </body>

</html>

<?php 
            }

        }
 
    $test = new data();
    $test->managedata();

?>