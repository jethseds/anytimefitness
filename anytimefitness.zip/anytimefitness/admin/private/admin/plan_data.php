<?php

    include '../../../config/config.php';

    // Class Function
    class senior extends Connection{ 

	        // senior Function
        public function managesenior(){ 

            $sql = "SELECT * FROM tbl_plan";
            $stmt = $this->conn()->query($sql);
            $id = 1;

            while ($row = $stmt->fetch()) { ?>

                <tr class="gradeU">

                    <td><?php echo $id; ?></td>
                    <td style="display: none;"><?php echo $row['id']; ?></td> 
                    <td><img src="../../../files/<?php echo $row['img']; ?>" width="100"></td> 
                    <td><?php echo $row['plan_name']; ?></td> 
                    <td><?php echo $row['amount']; ?></td> 
                    <td><?php echo $row['duration']; ?></td> 
                    <td style="display: flex;">

                        <button id="edit_van" class="btn btn-primary d-flex align-items-center" data-toggle="modal" data-target="#modalvanedit"><i class="fas fa-edit"></i> </button> &nbsp;
                        <button id="delete_van" class="btn btn-danger d-flex align-items-center" data-toggle="modal" data-target="#modalvandelete"><i class="fas fa-trash"></i> </button>

                    </td> 

                </tr>

<?php 
                $id++;  

            }

	    }
        
	}

    $senior = new senior();
    $senior->managesenior();
   
?>


<script>

       $(document).ready(function() {

        $('.dataTables-example').DataTable({ destroy: true,  retrieve: true, });
      
        });
       
</script>