
<!-- Create Modal -->
<div class="modal fade" id="modalvan" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="overflow-y: scroll;">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="createtitle">Create Reserved</h5>
        <h5 class="modal-title" id="edittitle">Edit Reserved</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form method="POST" enctype="multipart/form-data" id="myform">

        <div class="modal-body">

          <div class="form-group">

            <label>Customer Name</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Customer Name">

          </div>

          <div class="form-group">

            <label>Plan</label>
            <select name="plan_id" id="plan_id" class="form-control">
              <option value="">-- Select --</option>
              <?php
               $sql = "SELECT * FROM tbl_plan";
            $stmt = $this->conn()->query($sql);
            while ($row = $stmt->fetch()) { ?>
              <option value="<?php echo $row['id'] ?>"><?php echo $row['plan_name'] ?></option>
            <?php } ?>
            </select>

          </div>

          

        </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" id="submit" class="btn btn-danger">Yes</button>
   <!--      <button type="button" id="edit_senior_btn" class="btn btn-primary create_user_modal"data-dismiss="modal">Yes</button> -->
      
      </div>
      </form>
    </div>

  </div>

</div>




<!-- Edit Modal -->
<div class="modal fade" id="modalvanedit" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="overflow-y: scroll;">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="edittitle">Edit Reserved</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form method="POST" enctype="multipart/form-data" id="myformedit">

        <div class="modal-body">

          <input type="text" name="edit_reserved_id" id="edit_reserved_id" class="form-control">

          <div class="form-group">

            <label> Name</label>
            <input type="text" name="edit_name" id="edit_name" class="form-control" placeholder="Name">

          </div>

          <div class="form-group">

            <label>Plan</label>
            <select name="edit_plan_id" id="edit_plan_id" class="form-control">
              <option value="">-- Select --</option>
              <?php
               $sql = "SELECT * FROM tbl_plan";
            $stmt = $this->conn()->query($sql);
            while ($row = $stmt->fetch()) { ?>
              <option value="<?php echo $row['id'] ?>"><?php echo $row['plan_name'] ?></option>
            <?php } ?>
            </select>

          </div>

          <div class="form-group">

            <label>From Date</label>
            <input type="date" name="from_date" id="from_date" class="form-control">

          </div>

          <div class="form-group">

            <label>To Date</label>
            <input type="date" name="to_date" id="to_date" class="form-control">

          </div>

        </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" id="submit" class="btn btn-danger">Yes</button>
   <!--      <button type="button" id="edit_senior_btn" class="btn btn-primary create_user_modal"data-dismiss="modal">Yes</button> -->
      
      </div>
      </form>
    </div>

  </div>

</div>







<!-- Delete Modal -->
<div class="modal fade" id="modalvandelete" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="deletetitle">Delete Reserved</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form method="POST">

        <div class="modal-body">

          <input type="hidden" name="delete_reserved_id" id="delete_reserved_id" class="form-control">

          <h3> Are You Sure You To Delete Data Reserved ? </h3>

        </div>

      </form>
      

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="delete_van_btn" class="btn btn-primary create_user_modal"data-dismiss="modal">Yes</button>

      </div>

    </div>

  </div>

</div>


