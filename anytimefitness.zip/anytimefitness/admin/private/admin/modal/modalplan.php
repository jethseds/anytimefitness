
<!-- Create Modal -->
<div class="modal fade" id="modalvan" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="overflow-y: scroll;">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="createtitle">Create Plan</h5>
        <h5 class="modal-title" id="edittitle">Edit Plan</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form method="POST" enctype="multipart/form-data" id="myform">

        <div class="modal-body">

          <input type="hidden" name="van_id" id="van_id" class="form-control">

          <div class="form-group">

            <label>Image</label>
            <input type="file" name="img" id="img" class="form-control" accept=".png, .jpg, .jpeg">

          </div>

          <div class="form-group">

            <label>Plan Name</label>
            <input type="text" name="plan_name" id="plan_name" class="form-control" placeholder="Plan Name">

          </div>

          <div class="form-group">

            <label>Amount</label>
            <input type="number" name="amount" id="amount" class="form-control" placeholder="Amount">

          </div>

          <div class="form-group">

            <label>Duration Months</label>
            <input type="number" name="duration" id="duration" class="form-control" placeholder="Duration Months">

          </div>

        </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" id="submit" class="btn btn-danger">Yes</button>
   <!--      <button type="button" id="edit_senior_btn" class="btn btn-primary create_user_modal"data-dismiss="modal">Yes</button> -->
      
      </div>
      </form>
    </div>

  </div>

</div>






<!-- Edit Modal -->
<div class="modal fade" id="modalvanedit" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="overflow-y: scroll;">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="edittitle">Edit Plan</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form method="POST" enctype="multipart/form-data" id="myformedit">

        <div class="modal-body">

          <input type="hidden" name="edit_plan_id" id="edit_plan_id" class="form-control">

          <div class="form-group">

            <label>Image</label>
            <input type="file" name="edit_img" id="edit_img" class="form-control" accept=".png, .jpg, .jpeg">

          </div>

          <div class="form-group">

            <label>Plan Name</label>
            <input type="text" name="edit_plan_name" id="edit_plan_name" class="form-control" placeholder="Plan Name">

          </div>

          <div class="form-group">

            <label>Amount</label>
            <input type="text" name="edit_amount" id="edit_amount" class="form-control" placeholder="Amount">

          </div>

          <div class="form-group">

            <label>Duration Months</label>
            <input type="number" name="edit_duration" id="edit_duration" class="form-control" placeholder="Duration Months">

          </div>

        </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" id="submit" class="btn btn-danger">Yes</button>
   <!--      <button type="button" id="edit_senior_btn" class="btn btn-primary create_user_modal"data-dismiss="modal">Yes</button> -->
      
      </div>
      </form>
    </div>

  </div>

</div>







<!-- Delete Modal -->
<div class="modal fade" id="modalvandelete" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="deletetitle">Delete Plan</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form method="POST">

        <div class="modal-body">

          <input type="hidden" name="delete_plan_id" id="delete_plan_id" class="form-control">

          <h3> Are You Sure You To Delete Data Plan ? </h3>

        </div>

      </form>
      

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="delete_van_btn" class="btn btn-primary create_user_modal"data-dismiss="modal">Yes</button>

      </div>

    </div>

  </div>

</div>


