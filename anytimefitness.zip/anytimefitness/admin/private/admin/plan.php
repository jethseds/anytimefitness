
<?php include '../../login/session.php'; ?>

<!doctype html>

<html lang="en">
    
    <head>

        <!-- CSS -->
        <?php require_once 'header.php'; ?>
            
    </head>
    
    <body style="background-color: #ecf2fd;overflow-x: hidden;">

        <div class="success">Successfully Plan Added :)</div>
        <div class="success_delete success">Successfully Plan Deleted :)</div>
        <div class="success_edit success">Successfully Plan Edited :)</div>

        <div style="display: flex;">

            <!-- Sidebar -->
            <?php include '../include/sidebar.php'; ?>


            <!-- Top Navbar -->
            <?php include '../include/topnavbar.php'; ?>

        </div>

        <div class="whole_container_content">

            <div class="header_title">

                <h4>Plan</h4>

            </div>

            <div class="row p-4">
                
                <div class="col-lg-12 m-auto">
                
                    <div class="card border-0 card_table">


                
                        <div class="card-body">

                            <div id="createsenior" style="text-align: right;">
                                <!-- <a href="../../controller/exportseniorController.php" target="_blank" class="btn btn-success">Export Excel</a>&nbsp; -->
                                <button class="btn btn-danger" data-toggle="modal" data-target="#modalvan">Create Plan</button>

                            </div>

                            <br>

                            <div id="style-1" class="table-responsive">

                                <table class="table table-striped table-bordered table-sm dataTables-example" width="100%">
                                 
                                  <thead>
                                  
                                    <tr>

                                        <th class="th-sm">Id</th>
                                        <th class="th-sm d-none">Id</th>
                                        <th class="th-sm">Image</th>
                                        <th class="th-sm">Plan Name</th>
                                        <th class="th-sm">Amount</th>
                                        <th class="th-sm">Duration</th>
                                        <th class="th-sm">Action</th>
                                    
                                    </tr>
                                  </thead>

                                  <tbody id="table">

                                  </tbody>

                                </table>

                            </div>

                        </div>
                
                    </div>
                
                </div>

            </div>

        </div>

        <!-- JS -->
        <?php include 'footer.php'; ?>

        <?php include 'modal/modalplan.php'; ?>

        <script>

            function loadingdata(){

                $.ajax({

                    url: "plan_data.php",
                    type: "POST",
                    cache:false,

                    success: function(dataResult){

                        $('#table').html(dataResult)

                    }

                })

            }

            loadingdata()

            $('#myform').on("submit", function(e){
                e.preventDefault();

                var form_data = new FormData(this);

                $.ajax({

                    url: "../../../controller/createplanController.php",
                    method: "POST",
                    cache: false,
                    data: form_data,
                    
                    processData: false,
                    contentType: false,

                    success: function(dataResult){

                      
                        $( ".success" ).first().fadeIn( "slow" );

                        setTimeout(function(){

                            $( ".success" ).first().fadeOut( "slow" );
                            loadingdata();
                        },2000);

                        loadingdata();

                    }

                })

                $('#modalvan').modal('hide');
                $('.modal-backdrop.show').css("display","none")

            });

            $('#myformedit').on("submit", function(e){
                e.preventDefault();

                var form_data = new FormData(this);

                $.ajax({

                    url: "../../../controller/editplanController.php",
                    method: "POST",
                    cache: false,
                    data: form_data,
                    
                    processData: false,
                    contentType: false,

                    success: function(dataResult){

                      
                        $( ".success_edit" ).first().fadeIn( "slow" );

                        setTimeout(function(){

                            $( ".success_edit" ).first().fadeOut( "slow" );
                            loadingdata();
                        },2000);

                        loadingdata();

                    }

                })

                $('#modalvanedit').modal('hide');
                $('.modal-backdrop.show').css("display","none")

            });

            $('#delete_van_btn').click(function() {

                $.ajax({

                    url: "../../../controller/deleteplanController.php",
                    type: "POST",
                    cache: false,

                    data: {

                        delete_plan_id: $('#delete_plan_id').val(),

                    },

                    success: function(dataResult){

                        $( ".success_delete" ).first().fadeIn( "slow" );

                        setTimeout(function(){

                            $( ".success_delete" ).first().fadeOut( "slow" );

                        },2000);

                
                        $.ajax({

                            url: "plan_data.php",
                            type: "POST",
                            cache: false,
                            

                            success: function(dataResult){

                                $('#table').html(dataResult)

                            }

                        })

                    }

                })

            })

            $(document).on('click', "#createsenior", function(){
                
                $('#staticBackdrop').modal('show');

                $( "#createtitle" ).css( "display", "block" );
                $( "#edittitle" ).css( "display", "none" );

            })



            $(document).on('click', '#edit_van', function () {

                var row = $(this).closest('tr');
                var plan_id = row.find('td:eq(1)').text();
                var edit_plan_name = row.find('td:eq(3)').text();
                var edit_amount = row.find('td:eq(4)').text();
                var edit_duration = row.find('td:eq(5)').text();

                $('#edit_plan_id').val(plan_id);
                $('#edit_plan_name').val(edit_plan_name);
                $('#edit_amount').val(edit_amount);
                $('#edit_duration').val(edit_duration);

                $('#modalvanedit').modal('show');


            });

            $(document).on('click', '#delete_van', function () {

                var row = $(this).closest('tr');
                var delete_plan_id = row.find('td:eq(1)').text();

                $('#delete_plan_id').val(delete_plan_id);


            });

        </script>

    </body>

</html>