
<div class="wrapper_sidebar">
	
	<div class="sidebar_body">
		
		<div class="list-group">
		    
		    <a href="#" class="list-group-item border-0 list-group-item-action p-4" aria-current="true">
			   
			    <span class="logo text-danger"><i class="fas fa-copyright"></i> Admin </span>

		    </a>

		    <a href="dashboard.php?dashboard=dashboard" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['dashboard'])) { echo "active"; }  ?>">

			    <i class="fas fa-tachometer-alt-slow"></i> &nbsp;&nbsp; Dashboard

		    </a>

		    <a href="plan.php?plan=plan" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['plan'])) { echo "active"; }  ?>">

			    <i class="fas fa-list"></i> &nbsp;&nbsp; Plan

		    </a>

		    <a href="reserved.php?reserved=reserved" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['reserved'])) { echo "active"; }  ?>">

			    <i class="fas fa-table"></i> &nbsp;&nbsp; Reserved

		    </a>

		    <a href="history.php?history=history" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['history'])) { echo "active"; }  ?>">

			    <i class="fas fa-table"></i> &nbsp;&nbsp; History

		    </a>
		
		</div>

	</div>

</div>
