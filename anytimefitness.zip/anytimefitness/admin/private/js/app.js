
// Dropdown
$('#show_dropdown').click(function(){

	$('.dropdown').toggleClass('dropdown_show')

})

// Sidebar
$('#show_sidebar').click(function(){

	$('.wrapper_sidebar').toggleClass('wrapper_sidebar_hide')
	$('.topnavbar').toggleClass('topnavbar_width')
	$('.whole_container_content').toggleClass('whole_container_content_width')

})

// Sidebar Mobile
$('#show_sidebar_mobile').click(function(){

	$('.wrapper_sidebar').toggleClass('wrapper_sidebar_hide')
	$('.topnavbar').toggleClass('topnavbar_width')
	$('.whole_container_content').toggleClass('whole_container_content_width')

})

$(document).ready(function () {

  $('#dtBasicExample').DataTable({
  	 language: {
    paginate: {
      next: '<i class="fa fa-chevron-right" ></i>',
      previous: '<i class="fa fa-chevron-left" ></i>'
    }
  }
  });
  $('.dataTables_length').addClass('bs-select');
  $('#positionFilter').html('<input type="text" class="form-control" placeholder="Search by Position">');
});