
// let ctx2 = document.getElementById('myChart').getContext('2d');

// var gradientStroke = ctx2.createLinearGradient(500, 0, 100, 0);
// gradientStroke.addColorStop(0, "#dd006e");
// gradientStroke.addColorStop(1, "#dd006e");

// var gradientBkgrd = ctx2.createLinearGradient(0, 100, 0, 400);
// gradientBkgrd.addColorStop(0, "rgba(221,0,110,0.2)");
// gradientBkgrd.addColorStop(1, "rgba(221,0,110,0.08)");

// var myChart = new Chart(ctx2, {

//     type: 'line',

//     data: {

//         labels: ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"],

//         datasets: [
//             {

//                 fill: true,
//                 backgroundColor: gradientBkgrd,
//                 borderColor: gradientStroke,
//                 data: [500, 50, 2424,   14040,  14141,  4111,   4544,   47, 5555, 6811, 5000, 6000,0],
//                 pointBorderColor: "rgba(255,255,255,0)",
//                 pointBackgroundColor: "rgba(255,255,255,0)",
//                 pointBorderWidth: 0,
//                 pointHoverRadius: 8,
//                 pointHoverBackgroundColor: gradientStroke,
//                 pointHoverBorderColor: "rgba(220,220,220,1)",
//                 pointHoverBorderWidth: 4,
//                 pointRadius: 1,
//                 borderWidth: 2,
//                 pointHitRadius: 16,
//                 tension: 0.5

//             },


//         ]

//     },

//     options: {

 

//         plugins: {

//             legend: false
            
//         },

//         scales: {

//             y: {

//                 beginAtZero: true

//             },

//         }

//     }
    
// });















// let ctx = document.getElementById('myChart2').getContext('2d');

// var gradientStroke = ctx.createLinearGradient(500, 0, 100, 0);
// gradientStroke.addColorStop(0, "#dd006e");
// gradientStroke.addColorStop(1, "#dd006e");

// var gradientBkgrd = ctx.createLinearGradient(0, 100, 0, 400);
// gradientBkgrd.addColorStop(0, "rgba(221,0,110,0.2)");
// gradientBkgrd.addColorStop(1, "rgba(221,0,110,0.08)");

// var myChart = new Chart(ctx, {

//     type: 'line',

//     data: {

//         labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],

//         datasets: [
//             {

//                 fill: true,
//                 backgroundColor: gradientBkgrd,
//                 borderColor: gradientStroke,
//                 data: [500, 50, 2424,   14040,  14141,  4111,   4544, 0],
//                 pointBorderColor: "rgba(255,255,255,0)",
//                 pointBackgroundColor: "rgba(255,255,255,0)",
//                 pointBorderWidth: 0,
//                 pointHoverRadius: 8,
//                 pointHoverBackgroundColor: gradientStroke,
//                 pointHoverBorderColor: "rgba(220,220,220,1)",
//                 pointHoverBorderWidth: 4,
//                 pointRadius: 1,
//                 borderWidth: 2,
//                 pointHitRadius: 16,
//                 tension: 0.5

//             },


//         ]

//     },

//     options: {

 

//         plugins: {

//             legend: false
            
//         },



//         scales: {

//             y: {

//                 beginAtZero: true

//             },

//             x: {

//                 grid: {

//                   display: false,

//                 },

//             },

//             y: {

//                 grid: {

//                   display: false,

//                 },

//             },



//         }

//     }
    
// });