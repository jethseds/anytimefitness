<?php
  
  include '../config/config.php';
  session_start();
  
  class login extends Connection{
  
    public function loginuser(){ 

      if (isset($_POST['submit'])) {

        $username = $_POST['username'];
        $password = $_POST['password'];

        $sqlselect_users = "SELECT * FROM tbl_users_customers WHERE username = ?";
        $stmt = $this->conn()->prepare($sqlselect_users);
        $stmt->execute([$username]);

        if ($stmt->rowcount() > 0) {

          $row = $stmt->fetch();

          if (password_verify($password, $row['password'])) {
            
            $_SESSION['id'] = $row['id'];
            header('location:../welcome.php?welcome');

          }

        } else {

            echo "<script type='text/javascript'>alert('Invalid Username And Password');</script>";
            echo "<script>window.location.href='../login.php';</script>";

        } 
       
      } 
         
    }

  }

  $loginrun = new login();
  $loginrun->loginuser();

?>



