<?php

    include '../config/config.php';
    
    class add extends Connection{

        public function managadd(){
 
            $img = $_FILES['img']['name'];
            move_uploaded_file($_FILES['img']['tmp_name'], "../files/".$img);
            $plan_name = $_POST['plan_name'];
            $amount = $_POST['amount'];
            $duration = $_POST['duration'];


            $sqlinsert = " INSERT INTO tbl_plan (img,plan_name,amount,duration) VALUES (?,?,?,?) ";
            $statementinsert = $this->conn()->prepare($sqlinsert);
            $statementinsert->execute([$img,$plan_name,$amount,$duration]);

        }

    }

    $adddata = new add();
    $adddata->managadd();

?>



