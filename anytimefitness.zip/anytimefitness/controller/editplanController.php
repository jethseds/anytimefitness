<?php

    include '../config/config.php';
    
    class edit extends Connection{

        public function managedit(){
 
            $edit_plan_id = $_POST['edit_plan_id'];
   
            $img = $_FILES['edit_img']['name'];
            move_uploaded_file($_FILES['edit_img']['tmp_name'], "../files/".$img);
            $plan_name = $_POST['edit_plan_name'];
            $amount = $_POST['edit_amount'];
            $duration = $_POST['edit_duration'];

            if (empty($img) OR $img == '' OR !isset($img) ) {

                $sqlinsert = " UPDATE tbl_plan SET plan_name = ?, amount = ?, duration = ? WHERE id = '".$edit_plan_id."' ";
                $statementinsert = $this->conn()->prepare($sqlinsert);
                $statementinsert->execute([$plan_name,$amount,$duration]);

            } else {

                $sqlinsert = " UPDATE tbl_plan SET img = ?, plan_name = ?, amount = ?, duration = ? WHERE id = '".$edit_plan_id."' ";
                $statementinsert = $this->conn()->prepare($sqlinsert);
                $statementinsert->execute([$img,$plan_name,$amount,$duration]);

            }

        }

    }

    $editdata = new edit();
    $editdata->managedit();

?>



