<?php
    
    include '../session.php';
    include '../config/config.php';

    class deletevan extends Connection{

        public function managdeletevan(){

            $delete_plan_id = $_POST['delete_plan_id'];

            $sqlinsert = "DELETE FROM tbl_plan WHERE id = '".$delete_plan_id."' ";
            $statementinsert = $this->conn()->prepare($sqlinsert);
            $statementinsert->execute([]);

             echo json_encode(array("statusCode"=>200));

        }

    }

    $deletevanrun = new deletevan();
    $deletevanrun->managdeletevan();

?>
