<?php
    
    include '../session.php';
    include '../config/config.php';

    class deletevan extends Connection{

        public function managdeletevan(){

            $delete_reserved_id = $_POST['delete_reserved_id'];

            $sqlinsert = "DELETE FROM tbl_reserved WHERE id = '".$delete_reserved_id."' ";
            $statementinsert = $this->conn()->prepare($sqlinsert);
            $statementinsert->execute([]);

             echo json_encode(array("statusCode"=>200));

        }

    }

    $deletevanrun = new deletevan();
    $deletevanrun->managdeletevan();

?>
