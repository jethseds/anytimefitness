<?php

    include '../config/config.php';
    
    class add extends Connection{

        public function managadd(){

            $name = $_POST['name'];
            $plan_id = $_POST['plan_id'];


            $sqlinsert = " INSERT INTO tbl_reserved (name,plan_id) VALUES (?,?) ";
            $statementinsert = $this->conn()->prepare($sqlinsert);
            $statementinsert->execute([$name,$plan_id]);

        }

    }

    $adddata = new add();
    $adddata->managadd();

?>



