<?php

    include '../config/config.php';
    
    class edit extends Connection{

        public function managedit(){
 
            $edit_reserved_id = $_POST['edit_reserved_id'];
   
            $edit_name = $_POST['edit_name'];
            $edit_plan_id = $_POST['edit_plan_id'];
            $from_date = $_POST['from_date'];
            $to_date = $_POST['to_date'];

                $sqlinsert = " UPDATE tbl_reserved SET name = ?, plan_id = ?, from_date = ?, to_date = ? WHERE id = '".$edit_reserved_id."' ";
                $statementinsert = $this->conn()->prepare($sqlinsert);
                $statementinsert->execute([$edit_name,$edit_plan_id,$from_date,$to_date]);

        }

    }

    $editdata = new edit();
    $editdata->managedit();

?>



