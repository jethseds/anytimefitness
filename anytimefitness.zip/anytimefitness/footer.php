<footer class="container-fluid text-center">

  <a class="logo text-dark logo_footer mt-3" href="index.php">Pump <span style="color: #ff4730;">House</span></a>

  <p class="mt-3">Choose your Plan</p>

  <ul class="mt-3">
    
    <li><a class="nav-link text-dark" href="index.php">Home</a></li>
    <li><a class="nav-link text-dark" href="plan.php?plan">Plan</a></li>
    <li><a class="nav-link text-dark" href="training.php?training">Training</a></li>

  </ul>

  <ul class="pl-0 mt-5">
  
    <li class="nav-item" style="display: inline-block;"><a class="nav-link bg-dark btn ml-1 mr-1 text-white" href="#"><i class="fab fa-facebook-f"></i></a></li>
    <li class="nav-item" style="display: inline-block;"><a class="nav-link bg-dark btn ml-1 mr-1 text-white" href="#"><i class="fab fa-twitter"></i></a></li>
    <li class="nav-item" style="display: inline-block;"><a class="nav-link bg-dark btn ml-1 mr-1 text-white" href="#"><i class="fab fa-linkedin-in"></i></a></li>

  </ul>

  <div class="c_right">

    Copyright © 2022 All Rights Reserved

  </div>      

</footer>

<script src="asset/fontawesome.js"></script>

<script src="asset/jquery.slim.min.js"></script>
<script src="asset/bootstrap.bundle.min.js"></script>    
<script src="asset/jquery-3.4.1.min.js"></script>
<script src="asset/app.js"></script>

<script src="admin/private/bootstrap/bootstrap.bundle.min.js"></script>