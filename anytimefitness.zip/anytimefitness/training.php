
<!doctype html>

<html lang="en">

  <head><?php include 'head.php'; ?></head>
<style>
  .card{
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    transition: .4s;
  }
  .card:hover{
    box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
  }
</style>
  <body>

    <?php include 'header.php'; ?>

    <div class="container-fluid p-0">
      
      <!-- First Content Screen -->

        <div class="container-fluid bg-dark p-0 pt-5 pb-5 m-auto">
          
          <div class="card bg-transparent border-0 first_content">
            
            <div class="card-body text-center">
              
              <h3 class="text-white text-center">TRAINING</h3>
              <small class="text-white">HOME / TRAINING</small>
          
            </div>

          </div>

        </div>

      <!-- Second Content Screen -->
      <div class="container mt-5">
        <h2 class="text-center">Coaching that works for you and her and him and them.</h2>
        <p class="text-center"><small>Whether you’re a workout newbie or a fitness pro, our coaches lead team and one-on-one workouts that actually work. Workouts are designed using science and experience to maximize calorie burn, build strength, and cultivate community.</small></p>
        <div class="row">
          <div class="col-lg-4 col-sm-12 mt-3">
            <div class="card bg-transparent border-0">
              <div class="card-body p-0">
                <img src="images/t1.webp" width="100%">
                <div class="p-3 text-center">
                  <h3>FITNESS CONSULTATION</h3>
                  <p>Through a short survey, conversation, and a movement assessment, your coach will prescribe the perfect program to get you started and on track to meet your fitness goals.</p>
                  <button class="btn btn-dark">LEARN MORE</button>
                </div>
                
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-12 mt-3">
            <div class="card bg-transparent border-0">
              <div class="card-body p-0">
                <img src="images/t2.webp" width="100%">
                <div class="p-3 text-center">
                  <h3>GROUP WORKOUTS</h3>
                  <p>Full-body workouts are designed to build strength and endurance, using the energy of a small group or team of people around you and the expertise of the coach to maximize your results.</p>
                  <button class="btn btn-dark">LEARN MORE</button>
                </div>
                
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-12 mt-3">
            <div class="card bg-transparent border-0">
              <div class="card-body p-0">
                <img src="images/t3.webp" width="100%">
                <div class="p-3 text-center">
                  <h3>ONE-ON-ONE TRAINING</h3>
                  <p>One-on-one personalized workouts with your coach are designed to make you stronger from the inside out.</p>
                  <button class="btn btn-dark">LEARN MORE</button>
                </div>
                
              </div>
            </div>
          </div>
        </div>


      </div>

    </div>

    <br>
    <br>

    <?php include 'footer.php'; ?>


    <script>


    </script>

  </body>

</html>