
setInterval(function(){

    $(".wrapper_loading").fadeOut("slow");
    $("html").css("overflowY","scroll")

}, 1500)

$('#btnsearch').click(function(){

	$('.searching_wrapper').toggleClass('searching_wrapper_show')

})

$('.close').click(function(){

	$('.searching_wrapper').toggleClass('searching_wrapper_show')
	
})

