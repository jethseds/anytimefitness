-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2022 at 03:40 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `anytimefitness`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_plan`
--

CREATE TABLE `tbl_plan` (
  `id` int(11) NOT NULL,
  `img` text NOT NULL,
  `plan_name` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  `duration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_plan`
--

INSERT INTO `tbl_plan` (`id`, `img`, `plan_name`, `amount`, `duration`) VALUES
(14, 'wp2945268.jpg', 'chest', 2575, 6),
(15, 'hxh1.jpg', 'muscle', 3090, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reserved`
--

CREATE TABLE `tbl_reserved` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `plan_id` int(10) NOT NULL,
  `from_date` date NOT NULL DEFAULT current_timestamp(),
  `to_date` date NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_reserved`
--

INSERT INTO `tbl_reserved` (`id`, `name`, `plan_id`, `from_date`, `to_date`, `status`) VALUES
(34, 'bryan starl', 14, '2022-06-26', '2022-06-25', 1),
(35, 'sorar', 14, '2022-06-26', '2022-06-25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_admin`
--

CREATE TABLE `tbl_users_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users_admin`
--

INSERT INTO `tbl_users_admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$ip0DBnlowMuZw4jcBLZZt.xX7sXqARasQyKDhxAVq2MVHN5zLmkkq');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_customers`
--

CREATE TABLE `tbl_users_customers` (
  `id` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users_customers`
--

INSERT INTO `tbl_users_customers` (`id`, `fullname`, `email`, `contact`, `address`, `username`, `password`) VALUES
(9, 'sorar', 'sorar384@gmail.com', '09123456789', 'na', 'sorar384@gmail.com', '$2y$10$vznUxzdmFdB5KRd9PbF7tewzrXpyaH9Tr9cRfg4m4myKe4lUveQi2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_plan`
--
ALTER TABLE `tbl_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reserved`
--
ALTER TABLE `tbl_reserved`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users_admin`
--
ALTER TABLE `tbl_users_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users_customers`
--
ALTER TABLE `tbl_users_customers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_plan`
--
ALTER TABLE `tbl_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_reserved`
--
ALTER TABLE `tbl_reserved`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tbl_users_admin`
--
ALTER TABLE `tbl_users_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_users_customers`
--
ALTER TABLE `tbl_users_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
