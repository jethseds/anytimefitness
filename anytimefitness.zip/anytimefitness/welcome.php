
<!doctype html>

<html lang="en">

  <head><?php include 'head.php'; ?></head>

  <body>

    <div class="success">Successfully Cart Book :)</div>

    <?php include 'header.php'; ?>

    <div class="container-fluid">
      
      <!-- First Content Screen -->
      <div class="row" style="background-image: url(images/bg.jpg);background-position: center;background-size: cover;padding-top: 10rem;padding-bottom: 10rem;">

        <div class="container pt-5 pb-5 m-auto">
          
          <div class="card bg-transparent border-0 first_content">
            
            <div class="card-body">
              
              <h3 class="text-white text-center">No one else has your back, shoulders, and legs like us.</h3>
              <h1 class="text-dark text-center">JOIN NOW OUR <span style="color: #ff4730;">YOUTH SQUAD CLUB</span></h1>

              <p class="text-white text-center"><span class="text-danger">₱</span> Best Price Guaranteed</p>

              <div class="text-center"><button class="btn text-white rounded-0 pl-5 pr-5 pt-3 pb-3" style="background-color: #ff4730;">Join Our Club</button></div>
            </div>

          </div>

        </div>

      </div>

      <!-- Second Content Screen -->
      <div class="container mt-5">

        

        <div class="row">
          <div class="col-lg-6 col-sm-12">
            <div class="card bg-transparent border-0">
              <div class="card-body">
                <img src="images/about.jpg" width="100%">
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-sm-12">
            <div class="card bg-transparent border-0">
              <div class="card-body">
                <h5 style="color: #ff4730;">ABOUT US</h5>
                <h3 class=" mt-4 font-weight-bold">WE ARE READY TO MAKING YOU DIFFERENT FROM OTHERS</h3>
                <p class="mt-4 text-muted">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of orem psum you need to be sure.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks.</p>
                <div class="d-flex mt-4">
                  <div class="mr-3">
                    <span style="color: #ff4730;font-size: 28px;"><i class="fas fa-ski-lift"></i></span>
                  </div>
                  <div>
                    <p class="m-0" style="font-size: 24px;"><strong>Qualified Instructor</strong></p>
                    <small>Take a look at our round up of the best shows.</small>
                  </div>
                </div>
                <div class="d-flex mt-3">
                  <div class="mr-3">
                    <span style="color: #ff4730;font-size: 28px;"><i class="fas fa-dumbbell"></i></span>
                  </div>
                  <div>
                    <p class="m-0" style="font-size: 24px;"><strong>Get Fitness Training</strong></p>
                    <small>It has survived not only five centuries.</small>
                  </div>
                </div>

                <button class="btn text-white mt-5 pt-3 pb-3 pl-5 pr-5" style="background-color: #ff4730;">DISCOVER MORE</button>
              
              </div>

            </div>
          </div>
        </div>


      </div>

    </div>

    <br>
    <br>

    <?php include 'footer.php'; ?>


    <script>


    </script>

  </body>

</html>