

<!doctype html>

<html lang="en">

  <head><?php include 'head.php'; ?></head>
<style>
  .card{
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    transition: .4s;
  }
  .card:hover{
    box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
  }
</style>
  <body>

    <?php include 'header.php'; ?>
<?php

    // Class Function
    class senior extends Connection{ 

          // senior Function
        public function managesenior(){ 

          

      

?>
    <div class="container-fluid p-0">
      
      <!-- First Content Screen -->

        <div class="container-fluid bg-dark p-0 pt-5 pb-5 m-auto">
          
          <div class="card bg-transparent border-0 first_content">
            
            <div class="card-body text-center">
              
              <h3 class="text-white text-center">PLAN</h3>
              <small class="text-white">HOME / PLAN</small>
          
            </div>

          </div>

        </div>

      <!-- Second Content Screen -->
      <div class="container mt-5">

        <div class="row">
          

            <?php 
              $sql = "SELECT * FROM tbl_plan";
            $stmt = $this->conn()->query($sql);

            while ($row = $stmt->fetch()) { ?>
              <div class="col-lg-3 col-sm-12">
            <div class="card bg-transparent border-0" >
              <div class="card-body p-0 pt-4">
                <div class="text-center">
                  <img src="files/<?php echo $row['img'] ?>" width="100">
                </div>
                
                <div class="p-3">
                  <p>Plane Name: <?php echo $row['plan_name'] ?></p>
                  <p>Amount: PHP <?php echo $row['amount'] ?></p>
                  <p>Duration: <?php echo $row['duration'] ?> months</p>
                </div>
                
              </div>
            </div>
          </div>
          <?php } ?>



          
        </div>


      </div>

    </div>

    <br>
    <br>

    <?php include 'footer.php'; ?>


    <script>


    </script>

  </body>

</html>

<?php

      }
        
  }

    $senior = new senior();
    $senior->managesenior();
   
?>