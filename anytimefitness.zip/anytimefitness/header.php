<!-- <?php include 'loading.php'; ?>
 -->

 <?php include 'config/config.php'; ?>


<nav class="navbar navbar-expand-lg navbar-light shadow-sm">

  <a class="logo text-dark" href="index.php">Pump <span style="color: #ff4730;">House</span></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

    <span class="navbar-toggler-icon"></span>

  </button>

  <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ml-auto ul_menu">

      <li class="nav-item <?php if (isset($_GET['welcome'])): echo "active"; endif; ?>"><a class="nav-link" href="index.php">Home</a></li>
      <li class="nav-item <?php if (isset($_GET['plan'])): echo "active"; endif; ?>"><a class="nav-link" href="plan.php?plan">Plan</a></li>
      <li class="nav-item <?php if (isset($_GET['training'])): echo "active"; endif; ?>"><a class="nav-link" href="training.php?training">Training</a></li>

    </ul>
  </div>

</nav>

